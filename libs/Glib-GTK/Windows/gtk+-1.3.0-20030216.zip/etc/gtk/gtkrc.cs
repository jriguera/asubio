#$(gtkconfigdir)/gtkrc.iso-8859-2
#
# This file defines the fontsets for iso-8859-2 encoding
# make symliks or hardlinks to gtkrc.$LANG if your language uses iso-8859-2
# and a gtkrc.$LANG doesn't exist yet.

style  "gtk-default-iso-8859-2" {
       fontset = "-*-helvetica-medium-r-normal--12-*-*-*-*-*-iso8859-1,\
                  -*-arial-medium-r-normal--12-*-*-*-*-*-iso8859-1,\
		  -*-helvetica-medium-r-normal--12-*-*-*-*-*-iso8859-2,\
		  -*-arial-medium-r-normal--12-*-*-*-*-*-iso8859-2"
}
class "GtkWidget" style "gtk-default-iso-8859-2"

