#ifndef PKG_CONFIG_PARTIAL_GLIB_H
#define PKG_CONFIG_PARTIAL_GLIB_H

#include "glib-1.2.8/glib.h"

#endif
