# Version number and release date.
VERSION_NUMBER=0.12
RELEASE_DATE=2003-05-17      # in "date +%Y-%m-%d" format
