#!/bin/sh
exec ./test-names $top_srcdir/libuniname/UnicodeDataNames.txt
