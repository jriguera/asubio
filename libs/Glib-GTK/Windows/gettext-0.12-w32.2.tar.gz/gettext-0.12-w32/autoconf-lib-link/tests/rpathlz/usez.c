extern int rpathz_value (void);
int main () { return !(rpathz_value () == 5171); }
